<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Confirmación Seguimiento</title>
</head>

<body>
    <p>
        Se le informa que el ticket <?php echo e($id_atencion ?? 'N/A'); ?><br>
        A cargo del proveedor <?php echo e($nombre_proveedor ?? ''); ?> <?php echo e($rut_proveedor ?? ''); ?>.
    </p>

    <p>
        Ha sido reagendado para un nuevo seguimiento el cual se ejecutará en la siguiente fecha y hora:<br>
        <strong>
            <?php echo e($fecha_hora ?? 'Fecha no definida'); ?>

        </strong>
    </p>

    <p>
        Atte.<br>
        Walmart Mantención tiendas
    </p>
</body>

</html><?php /**PATH C:\laragon\www\WalmartBot\whatsapp-bot\resources\views/email/seguimiento_confirmacion.blade.php ENDPATH**/ ?>