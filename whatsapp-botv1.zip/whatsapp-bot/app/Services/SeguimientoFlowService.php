<?php

namespace App\Services;

use App\Models\Seguimiento;
use App\Jobs\CerrarSeguimientoXSilencio;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

class SeguimientoFlowService
{
    public function iniciarFlujo(Seguimiento $s): void
    {
        // ventana estándar de respuesta (ajústala a tu regla)
        $esperaHasta = now()->addMinutes(10);

        // Dejarlo listo para que el controller lo procese
        $s->update([
            'estado_seguimiento'     => 'MENSAJE_ENVIADO',
            'subestado_conversacion' => 'PREGUNTA_LLEGADA',
            'espera_hasta_at'        => $esperaHasta,
        ]);

        // Mensaje inicial estándar (igual para nuevo y reagendado)
        Http::withToken(env('WHATSAPP_SEGUIMIENTO_TOKEN'))->post(
            "https://graph.facebook.com/v22.0/" . env('WHATSAPP_SEGUIMIENTO_PHONE_ID') . "/messages",
            [
                'messaging_product' => 'whatsapp',
                'to' => $s->telefono_proveedor,
                'type' => 'template',
                'template' => [
                    'name' => 'seguimiento_saludo1',
                    'language' => [
                        'code' => 'es_CL',
                    ],
                    'components' => [
                        [
                            'type' => 'body',
                            'parameters' => [
                                [
                                    'type' => 'text',
                                    'text' => $s->nombre_proveedor,   // {{1}}
                                ],
                                [
                                    'type' => 'text',
                                    'text' => $s->rut_proveedor,      // {{2}}
                                ],
                                [
                                    'type' => 'text',
                                    'text' => (string) $s->id_atencion, // {{3}}
                                ],
                                [
                                    'type' => 'text',
                                    'text' => (string) $s->id_local,    // {{4}}
                                ],
                                [
                                    'type' => 'text',
                                    'text' => Carbon::parse(
                                        $s->ejecutar_desde_at ?? now()
                                    )
                                        ->setTimezone('America/Santiago')
                                        ->format('d-m-Y H:i'),            // {{5}}
                                ],
                            ],
                        ],
                    ],
                ],
            ]
        );

        // Cierre por silencio
        CerrarSeguimientoXSilencio::dispatch($s->id)->delay($esperaHasta);
    }
}
