<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Seguimiento;
use App\Services\SeguimientoFlowService;
use Illuminate\Support\Facades\Log;

class EjecutarSeguimientosPendientes extends Command
{
    protected $signature = 'seguimiento:ejecutar-pendientes';
    protected $description = 'Ejecuta seguimientos reagendados pendientes';

    public function handle(SeguimientoFlowService $flow)
    {
        $pendientes = Seguimiento::where('estado_seguimiento', 'PENDIENTE_FLUJO')
            ->whereNotNull('ejecutar_desde_at')
            ->where('ejecutar_desde_at', '<=', now())
            ->get();

        if ($pendientes->isEmpty()) {
            return Command::SUCCESS;
        }

        foreach ($pendientes as $s) {
            Log::info('▶ Ejecutando seguimiento reagendado', [
                'seguimiento_id' => $s->id,
                'ejecutar_desde_at' => (string) $s->ejecutar_desde_at,
            ]);

            // Inicia el flujo estándar
            $flow->iniciarFlujo($s);
        }

        return Command::SUCCESS;
    }
}
