<?php

namespace App\Jobs;

use App\Models\Seguimiento;
use App\Services\SeguimientoFlowService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class EjecutarSeguimientosPendientes implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle(SeguimientoFlowService $flow): void
    {
        $pendientes = Seguimiento::where('estado_seguimiento', 'PENDIENTE_FLUJO')
            ->whereNotNull('ejecutar_desde_at')
            ->where('ejecutar_desde_at', '<=', now())
            ->get();

        foreach ($pendientes as $s) {
            Log::info('▶ Ejecutando seguimiento pendiente', [
                'seguimiento_id' => $s->id,
                'ejecutar_desde_at' => (string) $s->ejecutar_desde_at,
            ]);

            // Arranca el flujo estándar
            $flow->iniciarFlujo($s);
        }
    }
}
