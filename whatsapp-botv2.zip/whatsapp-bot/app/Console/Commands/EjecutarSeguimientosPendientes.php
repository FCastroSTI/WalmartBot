<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Seguimiento;
use App\Services\SeguimientoFlowService;
use Illuminate\Support\Facades\Log;

class EjecutarSeguimientosPendientes extends Command
{
    protected $signature = 'seguimiento:ejecutar-pendientes';
    protected $description = 'Ejecuta seguimientos reagendados pendientes';

    public function handle(SeguimientoFlowService $flow)
    {
        $pendientes = Seguimiento::where(
            'estado_seguimiento',
            Seguimiento::ESTADO_PENDIENTE_FLUJO
        )
            ->whereNotNull('ejecutar_desde_at')
            ->where('ejecutar_desde_at', '<=', now())
            ->get();

        if ($pendientes->isEmpty()) {
            return Command::SUCCESS;
        }

        foreach ($pendientes as $s) {

            // 🔒 Bloqueo inmediato para evitar doble ejecución
            $s->update([
                'estado_seguimiento' => Seguimiento::ESTADO_MENSAJE_ENVIADO,
                'ejecutar_desde_at'  => null,
            ]);

            Log::info('▶ Ejecutando seguimiento reagendado', [
                'seguimiento_id' => $s->id,
            ]);

            // ▶ Arranca el flujo normal
            $flow->iniciarFlujo($s);
        }

        return Command::SUCCESS;
    }
}
