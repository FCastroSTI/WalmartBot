<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Confirmación Seguimiento</title>
</head>

<body>
    <p>
        Se le informa que el ticket {{ $id_atencion ?? 'N/A' }}<br>
        A cargo del proveedor {{ $nombre_proveedor ?? '' }} {{ $rut_proveedor ?? '' }}.
    </p>

    <p>
        Ha sido reagendado para un nuevo seguimiento el cual se ejecutará en la siguiente fecha y hora:<br>
        <strong>
            {{ $fecha_hora ?? 'Fecha no definida' }}
        </strong>
    </p>

    <p>
        Atte.<br>
        Walmart Mantención tiendas
    </p>
</body>

</html>